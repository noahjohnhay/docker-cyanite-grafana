/*! grafana - v3.1.1-1470047149 - 2016-08-01
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});